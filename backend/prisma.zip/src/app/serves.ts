import express, { Request, Response } from 'express';
import cors from 'cors';
import userRoutes from './routes/user';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/ping', (req: Request, res: Response) => res.json({ message: 'pong' }));

app.use('/users', userRoutes);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));